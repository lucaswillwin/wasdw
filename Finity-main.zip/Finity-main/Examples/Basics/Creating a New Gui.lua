local Finity = loadstring(game:HttpGet("https://raw.githubusercontent.com/LocalSmail/Finity/main/Library"))() -- loads and runs the code from the url

--[[

This is how you create a gui using: Fintiy.new()

The arguements parsed are optional.

Args:
Title (String), DarkMode (boolean), UseCustomTheme (boolean), CustomThemeName (String), HideToolTip (boolean), ToolTip (String)
]]
Finity.new("This is how you create a gui", true, false, "", true, "")

### Examples

Here you will find the examples for a single whole script or for individual functions/cheats to help guide you incase you dont understand the docs that are in place.

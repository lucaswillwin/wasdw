local Finity = loadstring(game:HttpGet("https://raw.githubusercontent.com/LocalSmail/Finity/main/Library"))()

--[[

Used to hide the credits print that shows up inside the console.

]]

Finity:EnableHubMode(true) -- enables it
--Finity:EnableHubMode(false) -- disables it

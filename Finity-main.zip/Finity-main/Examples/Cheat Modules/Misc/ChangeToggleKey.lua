local Finity = loadstring(game:HttpGet("https://raw.githubusercontent.com/LocalSmail/Finity/main/Library"))()

Finity:ChangeToggleKey("Semicolon")

local FinityWindow = Finity.new("ChangeToggleKey example", true, false, "", true, "")
